# Rockstar — a real, publishable practice app

A Progressive Web App (PWA) for practicing **electric guitar** and **drums**. Add songs,
practice chords with a metronome, record audio/video of yourself, and get **real, measured
feedback** on your timing and tuning. Installs to any phone's home screen and works offline.

This is a plain static project — no build step, no framework. Everything runs in the browser.

## What's in the box

```
rockstar-app/
├── index.html              app shell + styles
├── app.js                  all logic (audio engine, DSP feedback, storage)
├── manifest.webmanifest    PWA metadata (name, icons, colors)
├── sw.js                   service worker (offline + installability)
├── icons/                  app icons (192, 512, maskable, apple-touch)
└── api/coach.js            OPTIONAL serverless backend for AI coaching
```

## What's real vs. what's not (read this)

- **Real, on-device:** the song library, chord playback, metronome, drum pads, audio/video
  recording, and the **timing score, detected tempo, and tuning read**. Those numbers come
  from actual signal processing (note-onset detection + autocorrelation), not canned praise.
- **Not included, on purpose:** a reliable judge of physical technique (finger placement,
  posture, picking) from video. That's an unsolved problem; faking it would be dishonest.
- **Optional AI coaching:** sends a few video frames to Claude for *general written notes*.
  It's off until you deploy the backend below, and it can be wrong. Treat it as a second
  pair of eyes, not a verdict.

## Run it locally

A service worker and microphone/camera need a **secure context**, so use a local server
(not double-clicking the file):

```bash
cd rockstar-app
python3 -m http.server 8000
# open http://localhost:8000
```

`localhost` counts as secure, so recording and install both work.

## Publish it (the easy, free path)

Any static host works. Pick one:

- **Netlify:** drag the `rockstar-app` folder onto https://app.netlify.com/drop. Done.
- **Vercel:** `npm i -g vercel`, then `vercel` inside the folder. (Vercel also runs the
  `api/coach.js` backend automatically — see below.)
- **GitHub Pages:** push the folder to a repo, enable Pages on the branch/root.
- **Cloudflare Pages:** connect the repo, build command none, output dir `rockstar-app`.

Once it's on `https://`, open it on your phone and choose **Add to Home Screen**
(iOS Safari) or tap the **Install** button (Android Chrome). It then behaves like an app.

## Optional: turn on AI coaching

The app must never hold your Anthropic API key, so coaching goes through your own backend.

1. Deploy this folder to **Vercel** (it picks up `api/coach.js` as a function automatically).
2. In the Vercel project settings, add an environment variable
   `ANTHROPIC_API_KEY` = your key from https://console.anthropic.com.
3. In the app, open **Settings** and paste your endpoint, e.g.
   `https://your-project.vercel.app/api/coach`. Save.
4. The **AI coaching** button on a video take will now work.

Using Netlify/Cloudflare instead? Port `api/coach.js` to that platform's function format
(same logic: read `{ instrument, frames }`, call the Anthropic API server-side, return
`{ text }`).

## Optional: native app stores (App Store / Google Play)

PWAs can't be submitted to the stores directly. Wrap this with **Capacitor**:

```bash
npm init -y
npm i @capacitor/core @capacitor/cli @capacitor/ios @capacitor/android
npx cap init Rockstar com.yourname.rockstar --web-dir rockstar-app
npx cap add ios
npx cap add android
npx cap copy
npx cap open ios       # builds in Xcode  (needs a Mac + Apple Developer account, $99/yr)
npx cap open android   # builds in Android Studio (Google Play, $25 one-time)
```

You then sign and submit through Xcode/Android Studio and each store's review process.
That part is yours to do — it requires your developer accounts and identity.

## Customizing

- **Songs:** edit the `SEED` array in `app.js`, or add songs in-app (they save on-device).
- **Colors/branding:** the CSS variables at the top of `index.html` (`--amber`, `--bg`, etc.).
- **Icons:** replace the PNGs in `icons/` (keep the same filenames/sizes).
- **App name:** `manifest.webmanifest` (`name`, `short_name`) and the `<title>` in `index.html`.

## Browser notes

- Recording uses `MediaRecorder` + `getUserMedia`; supported on modern Chrome, Edge, Firefox,
  and iOS Safari 14.5+. Some iOS versions record to formats the in-browser decoder can't
  re-read for analysis — if timing analysis ever fails, use **Import file** with a wav/mp3/m4a.
- All recordings live in IndexedDB on the device. Clearing site data removes them; download
  anything you want to keep.
