// Optional AI-coaching backend for Rockstar.
// Deploy on Vercel (or adapt for Netlify/Cloudflare). Set env var ANTHROPIC_API_KEY.
// The app POSTs { instrument, frames:[base64 jpeg, ...] } and expects { text }.
//
// IMPORTANT: this is the ONLY place your API key should ever live. Never put it
// in the browser app. Honest caveat: this gives general written observations
// from a few frames — it is NOT a reliable judge of physical technique.

export default async function handler(req, res) {
  // CORS so your hosted PWA can call this.
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ text: "POST only." });

  try {
    const { instrument = "guitar", frames = [] } = req.body || {};
    if (!Array.isArray(frames) || frames.length === 0) {
      return res.status(400).json({ text: "No frames provided." });
    }
    const content = frames.slice(0, 4).map((data) => ({
      type: "image",
      source: { type: "base64", media_type: "image/jpeg", data },
    }));
    content.push({
      type: "text",
      text:
        `These are frames from a short video of someone practicing ${instrument}. ` +
        `Give brief, honest coaching ONLY on what you can actually see (framing, posture, ` +
        `whether hands/instrument are visible, obvious form issues). If you can't see the ` +
        `relevant body parts or instrument, say so plainly and suggest how to reframe the ` +
        `camera. Do NOT invent specifics you can't see. 4 sentences max.`,
    });

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 400,
        messages: [{ role: "user", content }],
      }),
    });
    const data = await r.json();
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join(" ").trim();
    return res.status(200).json({ text: text || "No response." });
  } catch (e) {
    return res.status(500).json({ text: "Coaching backend error." });
  }
}
