/* ============================================================
   Rockstar — app logic (real, publishable PWA build).
   - Library + settings: localStorage
   - Recordings: IndexedDB (persist across sessions)
   - Timing/tuning feedback: real DSP, runs entirely on-device
   - AI video coaching: calls a backend endpoint YOU configure
     (Settings tab). No API key ever lives in this file.
   ============================================================ */

/* ---------- persistence ---------- */
const mem = {};
const Store = {
  get(k){ try{ const v=localStorage.getItem("rs_"+k); return v?JSON.parse(v):(mem[k]??null);}catch(e){return mem[k]??null;} },
  set(k,v){ mem[k]=v; try{ localStorage.setItem("rs_"+k, JSON.stringify(v)); }catch(e){} }
};

/* IndexedDB for recorded takes (blobs + stats) */
const DB = (() => {
  let dbp;
  const open = () => dbp || (dbp = new Promise((res, rej) => {
    const r = indexedDB.open("rockstar", 1);
    r.onupgradeneeded = () => { if (!r.result.objectStoreNames.contains("clips")) r.result.createObjectStore("clips", { keyPath: "id" }); };
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  }));
  const tx = async (mode) => (await open()).transaction("clips", mode).objectStore("clips");
  return {
    async all(){ const s=await tx("readonly"); return new Promise((res)=>{const out=[];const c=s.openCursor();c.onsuccess=e=>{const cur=e.target.result;if(cur){out.push(cur.value);cur.continue();}else res(out.sort((a,b)=>b.ts-a.ts));};c.onerror=()=>res([]);}); },
    async put(v){ const s=await tx("readwrite"); return new Promise((res,rej)=>{const r=s.put(v);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);}); },
    async del(id){ const s=await tx("readwrite"); return new Promise((res)=>{const r=s.delete(id);r.onsuccess=()=>res();r.onerror=()=>res();}); }
  };
})();

/* ---------- audio engine ---------- */
let actx=null;
const ctx=()=>{ if(!actx) actx=new (window.AudioContext||window.webkitAudioContext)(); if(actx.state==="suspended") actx.resume(); return actx; };
const NOTES=["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
const FREQ={C:261.63,"C#":277.18,D:293.66,"D#":311.13,E:329.63,F:349.23,"F#":369.99,G:392,"G#":415.3,A:440,"A#":466.16,B:493.88};
const nf=(n,o=4)=>FREQ[n]*Math.pow(2,o-4);
const CHORDS={major:[0,4,7],minor:[0,3,7],"7":[0,4,7,10],m7:[0,3,7,10],sus4:[0,5,7],"5":[0,7],dim:[0,3,6],maj7:[0,4,7,11]};
function tone(freq,dur=.6,type="sawtooth",vol=.2,when=0){
  const c=ctx(),t=c.currentTime+when,o=c.createOscillator(),g=c.createGain(),f=c.createBiquadFilter();
  f.type="lowpass";f.frequency.value=2600;o.type=type;o.frequency.value=freq;
  g.gain.setValueAtTime(.001,t);g.gain.linearRampToValueAtTime(vol,t+.015);g.gain.exponentialRampToValueAtTime(.001,t+dur);
  o.connect(f);f.connect(g);g.connect(c.destination);o.start(t);o.stop(t+dur+.05);
}
function chord(root,type="major",dur=1){
  const ri=NOTES.indexOf(root);(CHORDS[type]||CHORDS.major).forEach((s,i)=>{
    const idx=(ri+s)%12,oct=3+Math.floor((ri+s)/12);tone(nf(NOTES[idx],oct),dur,"sawtooth",.13,i*.03);
  });
}
function drum(kind,when=0){
  const c=ctx(),t=c.currentTime+when;
  const noise=(d)=>{const b=c.createBuffer(1,c.sampleRate*d,c.sampleRate),a=b.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1;const s=c.createBufferSource();s.buffer=b;return s;};
  if(kind==="kick"){const o=c.createOscillator(),g=c.createGain();o.frequency.setValueAtTime(160,t);o.frequency.exponentialRampToValueAtTime(40,t+.2);g.gain.setValueAtTime(.9,t);g.gain.exponentialRampToValueAtTime(.001,t+.25);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+.3);}
  else if(kind==="snare"){const s=noise(.22),g=c.createGain(),f=c.createBiquadFilter();f.type="bandpass";f.frequency.value=2200;f.Q.value=.5;g.gain.setValueAtTime(.55,t);g.gain.exponentialRampToValueAtTime(.001,t+.18);s.connect(f);f.connect(g);g.connect(c.destination);s.start(t);s.stop(t+.22);}
  else if(kind==="hihat"){const s=noise(.06),g=c.createGain(),f=c.createBiquadFilter();f.type="highpass";f.frequency.value=8000;g.gain.setValueAtTime(.28,t);g.gain.exponentialRampToValueAtTime(.001,t+.05);s.connect(f);f.connect(g);g.connect(c.destination);s.start(t);s.stop(t+.07);}
  else if(kind==="tom"){const o=c.createOscillator(),g=c.createGain();o.frequency.setValueAtTime(200,t);o.frequency.exponentialRampToValueAtTime(80,t+.15);g.gain.setValueAtTime(.7,t);g.gain.exponentialRampToValueAtTime(.001,t+.2);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+.25);}
  else if(kind==="floor"){const o=c.createOscillator(),g=c.createGain();o.frequency.setValueAtTime(120,t);o.frequency.exponentialRampToValueAtTime(55,t+.2);g.gain.setValueAtTime(.75,t);g.gain.exponentialRampToValueAtTime(.001,t+.28);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+.32);}
  else if(kind==="crash"){const s=noise(.8),g=c.createGain(),f=c.createBiquadFilter();f.type="highpass";f.frequency.value=5000;g.gain.setValueAtTime(.35,t);g.gain.exponentialRampToValueAtTime(.001,t+.7);s.connect(f);f.connect(g);g.connect(c.destination);s.start(t);s.stop(t+.85);}
  else if(kind==="ride"){const s=noise(.45),g=c.createGain(),f=c.createBiquadFilter();f.type="bandpass";f.frequency.value=6000;f.Q.value=2;g.gain.setValueAtTime(.3,t);g.gain.exponentialRampToValueAtTime(.001,t+.4);s.connect(f);f.connect(g);g.connect(c.destination);s.start(t);s.stop(t+.46);}
}

/* ---------- playable guitar ---------- */
const GSTRINGS=[{open:"E",oct:4},{open:"B",oct:3},{open:"G",oct:3},{open:"D",oct:3},{open:"A",oct:2},{open:"E",oct:2}];
function fretNote(open,oct,fret){const i=NOTES.indexOf(open)+fret;return {note:NOTES[((i%12)+12)%12],oct:oct+Math.floor(i/12)};}
function pluck(freq,when=0){
  const c=ctx(),t=c.currentTime+when,o=c.createOscillator(),o2=c.createOscillator(),g=c.createGain(),f=c.createBiquadFilter();
  f.type="lowpass";f.frequency.setValueAtTime(3200,t);f.frequency.exponentialRampToValueAtTime(800,t+.6);
  o.type="triangle";o2.type="sawtooth";o.frequency.value=freq;o2.frequency.value=freq*2.001;
  g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.3,t+.006);g.gain.exponentialRampToValueAtTime(.0001,t+1.1);
  const g2=c.createGain();g2.gain.value=.18;o2.connect(g2);
  o.connect(f);g2.connect(f);f.connect(g);g.connect(c.destination);
  o.start(t);o2.start(t);o.stop(t+1.2);o2.stop(t+1.2);
}
const NFRETS=5;
function guitarSVG(){
  const x0=46, neckW=176, fw=neckW/NFRETS, bodyX=x0+neckW;
  const ys=[26,44,62,80,98,116]; const gauge=[1.4,1.6,1.9,2.3,2.8,3.3];
  let strings="",frets="",cells="",dots="",pickups="";
  // body shape (offset double-cutaway-ish)
  const body=`<path d="M${bodyX-6} 12 q70 -6 96 28 q18 26 6 52 q-12 30 -54 32 q-40 2 -54 -22 q-10 -18 4 -34 q-14 -16 -4 -34 q12 -18 56 -18 Z" fill="url(#bodyg)" stroke="#7a4a2c" stroke-width="2"/>`;
  // pickups + bridge + knobs
  pickups=`<rect x="${bodyX+44}" y="40" width="14" height="60" rx="3" fill="#2A241E"/><rect x="${bodyX+70}" y="40" width="14" height="60" rx="3" fill="#2A241E"/>
    <rect x="${bodyX+96}" y="46" width="9" height="48" rx="2" fill="#C9C0AE" stroke="#8a7d66"/>
    <circle cx="${bodyX+118}" cy="106" r="7" fill="#FBF4E4" stroke="#8a7d66" stroke-width="2"/><circle cx="${bodyX+138}" cy="112" r="7" fill="#FBF4E4" stroke="#8a7d66" stroke-width="2"/>`;
  // frets
  for(let f=1;f<NFRETS;f++){const fx=x0+f*fw;frets+=`<line x1="${fx}" y1="20" x2="${fx}" y2="122" stroke="#C9C0AE" stroke-width="2"/>`;}
  // inlay dots at frets 3 & 5
  [3,5].forEach(f=>{dots+=`<circle cx="${x0+(f-0.5)*fw}" cy="71" r="3.4" fill="#EDE2C9"/>`;});
  // strings (run nut -> bridge)
  ys.forEach((y,i)=>{strings+=`<line class="gstr" data-str="${i}" x1="${x0-2}" y1="${y}" x2="${bodyX+108}" y2="${y}" stroke="#d9cdb0" stroke-width="${gauge[i]}"/>`;});
  // tap targets: fret cells on the neck
  ys.forEach((y,i)=>{ for(let f=1;f<=NFRETS;f++){const cx=x0+(f-1)*fw;cells+=`<rect class="tap" data-fret="${i},${f}" x="${cx}" y="${y-8}" width="${fw}" height="16" rx="3"/>`;}
    // open-string strum zone over the body
    cells+=`<rect class="tap" data-open="${i}" x="${bodyX+2}" y="${y-8}" width="104" height="16" rx="3"/>`;});
  return `<svg viewBox="0 0 ${bodyX+150} 150" width="100%" style="display:block">
    <defs><linearGradient id="bodyg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#C2603A"/><stop offset="1" stop-color="#8a3f22"/></linearGradient></defs>
    <!-- headstock -->
    <path d="M2 50 L40 40 L40 102 L2 92 Z" fill="#2A241E"/>
    ${[48,62,76,90].map(y=>`<circle cx="14" cy="${y}" r="4" fill="#C9C0AE"/>`).slice(0,3).join("")}
    ${[48,62,76].map(y=>`<circle cx="30" cy="${y}" r="4" fill="#C9C0AE"/>`).join("")}
    <!-- neck -->
    <rect x="${x0}" y="18" width="${neckW}" height="106" rx="4" fill="#3a2c20"/>
    <rect x="${x0-4}" y="16" width="6" height="110" rx="2" fill="#EDE2C9"/>
    ${body}${pickups}${frets}${dots}${strings}${cells}
  </svg>`;
}

/* ---------- playable drum kit ---------- */
function drumkitSVG(){
  // each piece is a <g data-kit="..."> so the whole shape is tappable
  const cymbal=(x,y,rx,ry,kind)=>`<g class="kit" data-kit="${kind}"><line x1="${x}" y1="${y}" x2="${x}" y2="218" stroke="#8a7d66" stroke-width="2"/>
    <ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="url(#cym)" stroke="#6E6A33" stroke-width="1.5"/>
    <ellipse cx="${x}" cy="${y}" rx="${rx*0.5}" ry="${ry*0.5}" fill="none" stroke="#5a571f" stroke-width="1"/>
    <ellipse cx="${x}" cy="${y}" rx="${rx*0.16}" ry="${ry*0.16}" fill="#5a571f"/></g>`;
  const tom=(x,y,r,kind,label)=>`<g class="kit" data-kit="${kind}"><ellipse cx="${x}" cy="${y+r*0.7}" rx="${r}" ry="${r*0.5}" fill="#6b3f24"/>
    <rect x="${x-r}" y="${y}" width="${r*2}" height="${r*0.7}" fill="#6b3f24"/>
    <ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*0.5}" fill="#F4ECD8" stroke="#8a7d66" stroke-width="2"/>
    <ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*0.5}" fill="none" stroke="#C2603A" stroke-width="3" opacity=".5"/></g>`;
  const kick=(x,y,r)=>`<g class="kit" data-kit="kick"><line x1="${x}" y1="${y+r}" x2="${x}" y2="222" stroke="#8a7d66" stroke-width="3"/>
    <circle cx="${x}" cy="${y}" r="${r}" fill="#6b3f24" stroke="#4a2c16" stroke-width="3"/>
    <circle cx="${x}" cy="${y}" r="${r-7}" fill="#F4ECD8" stroke="#8a7d66" stroke-width="2"/>
    <circle cx="${x}" cy="${y}" r="${r-7}" fill="url(#kickg)"/>
    <text x="${x}" y="${y+5}" text-anchor="middle" font-family="Oswald,sans-serif" font-weight="700" font-size="15" letter-spacing="1" fill="#C2603A">ROCKSTAR</text></g>`;
  const snare=(x,y,r)=>`<g class="kit" data-kit="snare"><line x1="${x-14}" y1="${y}" x2="${x-20}" y2="216" stroke="#8a7d66" stroke-width="2"/><line x1="${x+14}" y1="${y}" x2="${x+20}" y2="216" stroke="#8a7d66" stroke-width="2"/>
    <ellipse cx="${x}" cy="${y+12}" rx="${r}" ry="${r*0.45}" fill="#9aa0a6"/><rect x="${x-r}" y="${y}" width="${r*2}" height="12" fill="#9aa0a6"/>
    <ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*0.45}" fill="#F4ECD8" stroke="#8a7d66" stroke-width="2"/></g>`;
  return `<svg viewBox="0 0 360 232" width="100%" style="display:block">
    <defs><radialGradient id="cym" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="#b9a94e"/><stop offset="1" stop-color="#6E6A33"/></radialGradient>
    <radialGradient id="kickg" cx="0.5" cy="0.4" r="0.6"><stop offset="0" stop-color="#FBF6E8"/><stop offset="1" stop-color="#e3d5b6"/></radialGradient></defs>
    ${cymbal(58,44,46,11,"crash")}
    ${cymbal(300,52,56,13,"ride")}
    <g class="kit" data-kit="hihat"><line x1="36" y1="118" x2="36" y2="220" stroke="#8a7d66" stroke-width="2"/>
      <ellipse cx="36" cy="112" rx="30" ry="7" fill="url(#cym)" stroke="#6E6A33"/><ellipse cx="36" cy="122" rx="30" ry="7" fill="url(#cym)" stroke="#6E6A33"/></g>
    ${tom(150,92,34,"tom")}
    ${tom(224,92,34,"floor")}
    ${snare(96,150,40)}
    ${kick(194,160,60)}
    ${tom(312,150,40,"floor")}
  </svg>`;
}

/* ---------- metronome ---------- */
let metro=null;
function startMetro(bpm){ stopMetro(); const period=60/bpm; let beat=0; const click=()=>{const acc=beat%4===0;tone(acc?1760:1320,.05,"square",acc?.25:.16);beat++;}; click(); metro=setInterval(click,period*1000); }
function stopMetro(){ if(metro){clearInterval(metro);metro=null;} }

/* ---------- seed songs ---------- */
const SEED=[
  {id:"q1",title:"Bohemian Rhapsody",band:"Queen",key:"Bb",tempo:72,chords:[["A#","major"],["D","minor"],["G","major"],["C","major"],["F","major"]]},
  {id:"q2",title:"We Will Rock You",band:"Queen",key:"A",tempo:82,chords:[["A","minor"],["D","major"],["G","major"]]},
  {id:"acdc1",title:"Back in Black",band:"AC/DC",key:"E",tempo:92,chords:[["E","5"],["D","5"],["A","5"],["G","5"]]},
  {id:"acdc2",title:"Highway to Hell",band:"AC/DC",key:"A",tempo:116,chords:[["A","major"],["D","major"],["G","major"]]},
  {id:"nir1",title:"Smells Like Teen Spirit",band:"Nirvana",key:"F",tempo:117,chords:[["F","5"],["A#","5"],["G#","5"],["D#","5"]]},
  {id:"led1",title:"Stairway to Heaven",band:"Led Zeppelin",key:"Am",tempo:82,chords:[["A","minor"],["G","major"],["F","major"]]},
  {id:"met1",title:"Enter Sandman",band:"Metallica",key:"Em",tempo:123,chords:[["E","5"],["G","5"],["A","5"]]},
  {id:"pf1",title:"Comfortably Numb",band:"Pink Floyd",key:"Bm",tempo:63,chords:[["B","minor"],["A","major"],["G","major"],["E","major"]]},
];

/* ---------- state ---------- */
const App={ inst:"guitar", view:"library", songs:[], clips:[], q:"", selected:null, coachUrl:"" };
const $=s=>document.querySelector(s);

function boot(){
  const saved=Store.get("songs"); App.songs=Array.isArray(saved)&&saved.length?saved:SEED.slice(); if(!saved)Store.set("songs",App.songs);
  App.inst=Store.get("inst")||"guitar"; App.coachUrl=Store.get("coachUrl")||"";
  syncInstUI();
  DB.all().then(c=>{App.clips=c; if(App.view==="clips")render();});
  render();
}

/* ---------- render ---------- */
function render(){
  const v=$("#view");
  if(App.view==="library")v.innerHTML=Library();
  else if(App.view==="song")v.innerHTML=SongView();
  else if(App.view==="record")v.innerHTML=RecordView();
  else if(App.view==="clips")v.innerHTML=ClipsView();
  else if(App.view==="settings")v.innerHTML=SettingsView();
  bind(); renderNav();
}

function Library(){
  const list=App.songs.filter(s=>{const q=App.q.toLowerCase();return !q||s.title.toLowerCase().includes(q)||s.band.toLowerCase().includes(q);});
  return `<h2 class="sectiontitle">Set list</h2>
  <p class="sub">Tap a track to practice its chords with a metronome — then record yourself and check your timing.</p>
  <div class="field"><input id="search" placeholder="Search songs or bands…" value="${esc(App.q)}"></div>
  <button class="btn primary block" id="addSong" style="margin-bottom:14px">+ Add a song</button>
  ${list.length?list.map(songRow).join(""):`<div class="empty">No songs match “${esc(App.q)}”. Add one above.</div>`}
  <div style="height:18px"></div>
  <div class="note">Your library is saved on this device. Recordings are saved too — see the Takes tab.</div>`;
}
function songRow(s){return `<button class="songbtn" data-song="${s.id}"><div><div class="songtitle">${esc(s.title)}</div><div class="songband">${esc(s.band)} · key ${esc(s.key||"—")}</div></div><span class="chip">${s.tempo||"—"} BPM</span></button>`;}

function SongView(){
  const s=App.songs.find(x=>x.id===App.selected); if(!s){App.view="library";return Library();}
  const guitar=App.inst==="guitar";
  return `<div class="row" style="margin:18px 0 2px"><button class="btn ghost" id="back">← Set list</button><span class="x" data-del="${s.id}" role="button" title="Delete">🗑</span></div>
  <h2 class="sectiontitle" style="margin-top:6px">${esc(s.title)}</h2>
  <p class="sub">${esc(s.band)} · key ${esc(s.key||"—")} · ${s.tempo||"—"} BPM</p>
  <div class="card"><div class="eyebrow">Chords — tap to hear</div>
    <div class="chords">${(s.chords||[]).map((c,i)=>`<button class="chord" data-chord="${i}">${c[0]}${chordSuffix(c[1])}</button>`).join("")||'<span class="muted">No chords yet.</span>'}</div>
    <div style="height:12px"></div><button class="btn block" id="playProg">▶ Play progression</button></div>
  <div class="card"><div class="row"><div class="eyebrow">Metronome</div><span class="pill" id="bpmLabel">${s.tempo||90} BPM</span></div>
    <div class="row" style="margin-top:10px;gap:8px"><button class="btn" id="bpmDown">–</button><input id="bpm" type="range" min="40" max="220" value="${s.tempo||90}" style="flex:1"><button class="btn" id="bpmUp">+</button></div>
    <button class="btn primary block" id="metroBtn" style="margin-top:12px">Start metronome</button></div>
  ${guitar
    ? `<div class="card"><div class="eyebrow">Guitar — tap frets or strum the body</div><div id="instrument" class="instrument">${guitarSVG()}</div><button class="btn block" id="strumBtn" style="margin-top:10px">Strum open chord</button></div>`
    : `<div class="card"><div class="eyebrow">Drum kit — tap a drum or cymbal</div><div id="instrument" class="instrument">${drumkitSVG()}</div></div>`}
  <button class="btn hot block" id="goRecord" style="margin-top:14px">● Record yourself playing this</button>`;
}

/* ---------- record + analysis ---------- */
let stream=null,recorder=null,chunks=[],levelRAF=null,lastBlob=null,lastType="audio",recStart=0,mode="audio";
function RecordView(){
  const s=App.selected?App.songs.find(x=>x.id===App.selected):null;
  return `<h2 class="sectiontitle">Record & check</h2>
  <p class="sub">${s?`Playing along to <b>${esc(s.title)}</b> — target ${s.tempo} BPM.`:"Free practice — record audio or video, then get real feedback on your timing."}</p>
  <div class="card"><div class="row"><div class="eyebrow">Mode</div>
    <div class="seg" style="margin-left:auto"><button id="mAudio" aria-pressed="true">Audio</button><button id="mVideo" aria-pressed="false">Video</button></div></div>
    <video id="prev" class="preview" playsinline muted style="margin-top:12px;display:none"></video>
    <canvas id="meter" class="viz" style="margin-top:12px"></canvas>
    <div class="row" style="margin-top:12px;gap:10px"><button class="btn hot" id="recBtn" style="flex:1">● Record</button><button class="btn" id="impBtn">Import file</button><input id="impInput" type="file" accept="audio/*,video/*" hidden></div>
    <div id="recStatus" class="hint" style="margin-top:10px"></div></div>
  <div id="result"></div>
  <div class="card"><div class="eyebrow">How the feedback works — and its limits</div>
    <p class="hint" style="margin-top:8px">Timing and tuning numbers are <b>measured</b> from your audio with real signal processing (note-onset detection for rhythm, autocorrelation for pitch). They run entirely on your device.</p>
    <p class="warn" style="margin-top:8px">This app does <b>not</b> judge physical technique (hand position, posture, picking) from video — that's beyond what can be done reliably. The optional “AI coaching” button needs a backend you set up in <b>Settings</b>; it returns general written observations and can be wrong.</p></div>`;
}
function setMode(m){mode=m;$("#mAudio")?.setAttribute("aria-pressed",m==="audio");$("#mVideo")?.setAttribute("aria-pressed",m==="video");const p=$("#prev");if(p)p.style.display=m==="video"?"block":"none";}

async function startRec(){
  try{ stream=await navigator.mediaDevices.getUserMedia(mode==="video"?{audio:true,video:{facingMode:"user"}}:{audio:true}); }
  catch(e){ $("#recStatus").innerHTML=`<span class="warn">Couldn't access your ${mode==="video"?"camera":"microphone"}. This needs an https page and permission. You can still use <b>Import file</b> to analyze an existing recording.</span>`; return; }
  if(mode==="video"){const p=$("#prev");p.srcObject=stream;p.play().catch(()=>{});}
  meterLoop(stream);
  chunks=[]; const mime=mode==="video"?pick(["video/webm;codecs=vp9,opus","video/webm","video/mp4"]):pick(["audio/webm;codecs=opus","audio/webm","audio/mp4"]);
  recorder=new MediaRecorder(stream,mime?{mimeType:mime}:undefined);
  recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
  recorder.onstop=onRecStop; recorder.start(); recStart=Date.now(); lastType=mode;
  const b=$("#recBtn");b.classList.remove("hot");b.textContent="■ Stop";
  $("#recStatus").innerHTML=`<span class="row" style="gap:8px"><span class="recdot"></span> Recording… play now.</span>`;
}
function pick(list){if(!window.MediaRecorder)return null;return list.find(t=>MediaRecorder.isTypeSupported(t))||null;}
function stopRec(){try{recorder&&recorder.state!=="inactive"&&recorder.stop();}catch(e){}cleanupStream();}
function cleanupStream(){if(levelRAF)cancelAnimationFrame(levelRAF);levelRAF=null;if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;}const p=$("#prev");if(p)p.srcObject=null;}
function onRecStop(){
  const type=lastType==="video"?(recorder.mimeType||"video/webm"):(recorder.mimeType||"audio/webm");
  lastBlob=new Blob(chunks,{type}); const dur=((Date.now()-recStart)/1000).toFixed(1);
  const b=$("#recBtn");b.classList.add("hot");b.textContent="● Record";
  $("#recStatus").innerHTML=`Captured ${dur}s. Analyzing…`; analyze(lastBlob,lastType==="video");
}
let vuSmooth=0;
function drawVU(g,W,H,level){
  // cream face
  g.clearRect(0,0,W,H);
  const cx=W/2, cy=H*0.96, R=H*0.78;
  const A0=-Math.PI*0.74, A1=-Math.PI*0.26; // sweep left→right across the top
  // scale arc
  g.lineWidth=2; g.strokeStyle="rgba(42,36,30,.5)";
  g.beginPath(); g.arc(cx,cy,R,A0,A1); g.stroke();
  // red zone (last 22%)
  g.lineWidth=4; g.strokeStyle="#B23A2E";
  g.beginPath(); g.arc(cx,cy,R,A0+(A1-A0)*0.78,A1); g.stroke();
  // ticks
  for(let i=0;i<=10;i++){
    const a=A0+(A1-A0)*(i/10); const r2=R-(i%5===0?12:7);
    g.strokeStyle=i>=8?"#B23A2E":"rgba(42,36,30,.6)"; g.lineWidth=i%5===0?2:1;
    g.beginPath(); g.moveTo(cx+Math.cos(a)*R,cy+Math.sin(a)*R); g.lineTo(cx+Math.cos(a)*r2,cy+Math.sin(a)*r2); g.stroke();
  }
  // labels
  g.fillStyle="rgba(42,36,30,.65)"; g.font="700 10px 'Space Mono',monospace"; g.textAlign="center";
  g.fillText("-20",cx+Math.cos(A0)*R*0.78, cy+Math.sin(A0)*R*0.78+4);
  g.fillText("0",cx+Math.cos((A0+A1)/2)*R*0.74, cy+Math.sin((A0+A1)/2)*R*0.74+4);
  g.fillStyle="#B23A2E"; g.fillText("+3",cx+Math.cos(A1)*R*0.78, cy+Math.sin(A1)*R*0.78+4);
  g.fillStyle="rgba(42,36,30,.45)"; g.font="600 9px 'Oswald',sans-serif"; g.fillText("V U   M E T E R",cx,cy-R*0.30);
  // needle
  vuSmooth += (level-vuSmooth)*0.35;
  const a=A0+(A1-A0)*Math.min(1,vuSmooth);
  g.strokeStyle="#7a2a1f"; g.lineWidth=2.5;
  g.beginPath(); g.moveTo(cx,cy); g.lineTo(cx+Math.cos(a)*(R-4),cy+Math.sin(a)*(R-4)); g.stroke();
  g.fillStyle="#2A241E"; g.beginPath(); g.arc(cx,cy,5,0,7); g.fill();
}
function meterLoop(strm){
  const c=ctx(),src=c.createMediaStreamSource(strm),an=c.createAnalyser();an.fftSize=1024;src.connect(an);
  const data=new Uint8Array(an.fftSize),cv=$("#meter");if(!cv)return;const g=cv.getContext("2d");
  const dpr=Math.min(devicePixelRatio||1,2);cv.width=cv.clientWidth*dpr;cv.height=cv.clientHeight*dpr;g.setTransform(dpr,0,0,dpr,0,0);
  const W=cv.clientWidth,H=cv.clientHeight; vuSmooth=0;
  const draw=()=>{ an.getByteTimeDomainData(data);
    let sum=0; for(let i=0;i<data.length;i++){const v=(data[i]-128)/128;sum+=v*v;}
    const rms=Math.sqrt(sum/data.length); const level=Math.min(1, rms*4.5);
    drawVU(g,W,H,level); levelRAF=requestAnimationFrame(draw); };
  draw();
}
// static VU gauge (SVG) for the feedback panel, value 0..100
function vuGaugeSVG(value){
  const v=Math.max(0,Math.min(100,value||0))/100;
  const cx=110,cy=96,R=80,A0=-134,A1=-46;
  const ang=(A0+(A1-A0)*v)*Math.PI/180;
  const nx=cx+Math.cos(ang)*(R-6), ny=cy+Math.sin(ang)*(R-6);
  const tick=(p)=>{const a=(A0+(A1-A0)*p)*Math.PI/180;const r2=R-(p>0.78?12:8);return `<line x1="${cx+Math.cos(a)*R}" y1="${cy+Math.sin(a)*R}" x2="${cx+Math.cos(a)*r2}" y2="${cy+Math.sin(a)*r2}" stroke="${p>=0.8?'#B23A2E':'rgba(42,36,30,.55)'}" stroke-width="${p%0.5<0.06?2:1}"/>`;};
  let ticks=""; for(let i=0;i<=10;i++)ticks+=tick(i/10);
  const arc=(p0,p1,col,w)=>{const s=(A0+(A1-A0)*p0)*Math.PI/180,e=(A0+(A1-A0)*p1)*Math.PI/180;return `<path d="M ${cx+Math.cos(s)*R} ${cy+Math.sin(s)*R} A ${R} ${R} 0 0 1 ${cx+Math.cos(e)*R} ${cy+Math.sin(e)*R}" fill="none" stroke="${col}" stroke-width="${w}"/>`;};
  return `<svg viewBox="0 0 220 110" width="100%" style="max-width:240px;display:block;margin:6px auto 0">
    ${arc(0,1,'rgba(42,36,30,.5)',2)}${arc(0.78,1,'#B23A2E',4)}${ticks}
    <text x="${cx}" y="${cy-26}" text-anchor="middle" font-family="Oswald,sans-serif" font-size="9" letter-spacing="2" fill="rgba(42,36,30,.5)">TIMING</text>
    <line x1="${cx}" y1="${cy}" x2="${nx}" y2="${ny}" stroke="#7a2a1f" stroke-width="2.5"/>
    <circle cx="${cx}" cy="${cy}" r="5" fill="#2A241E"/>
  </svg>`;
}

async function analyze(blob,isVideo){
  let buf;
  try{const ab=await blob.arrayBuffer();buf=await ctx().decodeAudioData(ab.slice(0));}
  catch(e){$("#result").innerHTML=`<div class="card"><div class="warn">Couldn't decode this recording's audio in your browser. Try Import with a .wav, .mp3, or .m4a file.</div></div>`;await saveClip(blob,isVideo,null);return;}
  const sr=buf.sampleRate,ch=buf.getChannelData(0);
  const onsets=detectOnsets(ch,sr),tempo=estimateTempo(onsets),steady=steadiness(onsets);
  const pitch=App.inst==="guitar"?detectPitch(ch,sr):null;
  const target=App.selected?(App.songs.find(x=>x.id===App.selected)||{}).tempo:null;
  await saveClip(blob,isVideo,{tempo,steady});
  $("#result").innerHTML=Feedback({tempo,steady,pitch,target,onsets:onsets.length,dur:buf.duration,isVideo}); bindFeedback();
}
function detectOnsets(x,sr){
  const hop=512,win=1024,flux=[];
  for(let i=0;i+win<x.length;i+=hop){let e=0;for(let j=0;j<win;j++){const s=x[i+j];e+=s*s;}flux.push(e);}
  const onsets=[],t=hop/sr,mean=flux.reduce((a,b)=>a+b,0)/(flux.length||1);
  for(let i=2;i<flux.length-2;i++){const d=flux[i]-flux[i-1];if(d>mean*0.6&&flux[i]>flux[i-1]&&flux[i]>=flux[i+1]&&flux[i]>mean*0.8){const time=i*t;if(!onsets.length||time-onsets[onsets.length-1]>0.12)onsets.push(time);}}
  return onsets;
}
function estimateTempo(o){if(o.length<3)return null;const i=[];for(let k=1;k<o.length;k++)i.push(o[k]-o[k-1]);i.sort((a,b)=>a-b);const m=i[Math.floor(i.length/2)];if(!m)return null;let b=60/m;while(b<60)b*=2;while(b>200)b/=2;return Math.round(b);}
function steadiness(o){if(o.length<4)return null;const i=[];for(let k=1;k<o.length;k++)i.push(o[k]-o[k-1]);const m=i.reduce((a,b)=>a+b,0)/i.length;const sd=Math.sqrt(i.reduce((a,b)=>a+(b-m)*(b-m),0)/i.length);const cv=sd/m;return Math.max(0,Math.min(100,Math.round((1-Math.min(cv,0.5)/0.5)*100)));}
function detectPitch(x,sr){
  const N=2048,start=Math.max(0,Math.floor(x.length/2)-N);let rms=0;for(let i=0;i<N;i++){const s=x[start+i]||0;rms+=s*s;}rms=Math.sqrt(rms/N);if(rms<0.01)return null;
  let best=-1,bestoff=-1;const buf=x.subarray(start,start+N);
  for(let off=20;off<1000;off++){let c=0;for(let i=0;i<N-off;i++)c+=buf[i]*buf[i+off];if(c>best){best=c;bestoff=off;}}
  if(bestoff<=0)return null;const freq=sr/bestoff;if(freq<60||freq>1200)return null;
  const midi=69+12*Math.log2(freq/440),round=Math.round(midi),cents=Math.round((midi-round)*100),name=NOTES[((round%12)+12)%12];
  return {freq:Math.round(freq),note:name,cents};
}

function Feedback({tempo,steady,pitch,target,onsets,dur,isVideo}){
  const sc=steady??0;
  const verdict=steady==null?"Not enough clear hits to measure rhythm — play longer with distinct notes/strums.":sc>=80?"Tight. Your timing is steady.":sc>=55?"Decent, but the gaps drift. Practice slow with the metronome.":"The rhythm is uneven. Slow right down and lock to the click before speeding up.";
  let tempoLine=tempo?(target?`You played around <b>${tempo} BPM</b> vs target <b>${target}</b> — ${Math.abs(tempo-target)<=4?"right on the money.":(tempo>target?"you're rushing ahead.":"you're dragging behind.")}`:`Detected tempo ≈ <b>${tempo} BPM</b>.`):"";
  let pitchLine="";
  if(pitch){const off=Math.abs(pitch.cents);pitchLine=`Strongest note read as <b>${pitch.note}</b> (${pitch.freq} Hz), ${off<=8?"well in tune":(pitch.cents>0?`${off}¢ sharp`:`${off}¢ flat`)}. <span class="hint">(single-note reading; chords confuse this.)</span>`;}
  const src=lastBlob?URL.createObjectURL(lastBlob):"";
  return `<div class="card" style="margin-top:14px"><div class="eyebrow">Your take — measured feedback</div>
    ${src?(isVideo?`<video class="preview" controls playsinline src="${src}" style="margin-top:10px"></video>`:`<audio controls src="${src}"></audio>`):""}
    <div class="grid2" style="margin-top:12px"><div class="stat"><b>${tempo??"—"}</b><small>tempo bpm</small></div><div class="stat"><b>${steady??"—"}</b><small>timing score /100</small></div></div>
    ${vuGaugeSVG(sc)}
    <div class="scorebar" style="margin-top:10px"><i style="width:${sc}%"></i></div>
    <p style="margin-top:12px">${tempoLine}</p><p style="margin-top:6px">${verdict}</p>${pitchLine?`<p style="margin-top:6px">${pitchLine}</p>`:""}
    <p class="hint" style="margin-top:8px">Measured from ${onsets} detected hits over ${dur.toFixed(1)}s.</p>
    <div class="row" style="margin-top:12px;gap:10px"><button class="btn" id="dl">Download take</button>${isVideo?`<button class="btn primary" id="coach">AI coaching</button>`:""}</div>
    <div id="coachOut"></div></div>`;
}
function bindFeedback(){
  $("#dl")?.addEventListener("click",()=>{if(!lastBlob)return;const a=document.createElement("a");a.href=URL.createObjectURL(lastBlob);a.download=`take.${lastType==="video"?"webm":"webm"}`;a.click();});
  $("#coach")?.addEventListener("click",coach);
}
async function coach(){
  const out=$("#coachOut");
  if(!App.coachUrl){out.innerHTML=`<div class="warn" style="margin-top:12px">AI coaching needs a backend. Open the <b>Settings</b> tab and paste your coaching endpoint URL. See the README for a ready-to-deploy example.</div>`;return;}
  out.innerHTML=`<p class="hint" style="margin-top:10px">Capturing frames and contacting your coaching backend…</p>`;
  try{
    const v=document.querySelector("#result video");if(!v){out.innerHTML=`<p class="warn">No video to analyze.</p>`;return;}
    await v.play().catch(()=>{});v.pause();
    const frames=[],cv=document.createElement("canvas");
    const grab=()=>{cv.width=320;cv.height=Math.round(320*(v.videoHeight/v.videoWidth||0.56));cv.getContext("2d").drawImage(v,0,0,cv.width,cv.height);return cv.toDataURL("image/jpeg",0.6).split(",")[1];};
    for(const frac of [0.2,0.5,0.8]){v.currentTime=v.duration*frac;await new Promise(r=>{v.onseeked=r;setTimeout(r,400);});frames.push(grab());}
    const res=await fetch(App.coachUrl,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({instrument:App.inst,frames})});
    const data=await res.json(); const text=(data.text||data.message||"").trim();
    out.innerHTML=`<div class="note" style="margin-top:12px"><b>AI coaching (can be wrong):</b><br>${esc(text||"No response from backend.")}</div>`;
  }catch(e){ out.innerHTML=`<div class="warn" style="margin-top:12px">Couldn't reach your coaching backend. Check the URL in Settings and that it's online. Your measured timing/tuning feedback above works regardless.</div>`; }
}

async function saveClip(blob,isVideo,stats){
  const id="c"+Date.now(); const rec={id,ts:Date.now(),blob,isVideo,stats,song:App.selected,when:new Date().toLocaleString()};
  try{await DB.put(rec);}catch(e){}
  App.clips.unshift(rec);
}

function ClipsView(){
  return `<h2 class="sectiontitle">Your takes</h2>
  <p class="sub">Saved on this device across sessions. Download anything you want to keep elsewhere.</p>
  ${App.clips.length?App.clips.map(c=>`<div class="card"><div class="row"><div class="eyebrow">${c.isVideo?"Video":"Audio"} · ${esc(c.when||"")}</div>${c.stats?`<span class="pill" style="margin-left:auto">${c.stats.tempo||"—"} BPM · ${c.stats.steady??"—"}/100</span>`:""}</div>
    <div data-clip="${c.id}"></div>
    <div class="row" style="margin-top:10px;gap:10px"><button class="btn" data-dlclip="${c.id}" style="flex:1">Download</button><button class="btn ghost" data-delclip="${c.id}">Delete</button></div></div>`).join(""):`<div class="empty">No takes yet. Head to Record and play something.</div>`}`;
}

function SettingsView(){
  return `<h2 class="sectiontitle">Settings</h2>
  <p class="sub">Optional configuration. The app works fully without any of this.</p>
  <div class="card"><div class="eyebrow">AI coaching backend (optional)</div>
    <p class="hint" style="margin:8px 0">Paste the URL of your own serverless function that talks to the Claude API. This keeps your API key on the server, never in the app. A ready-to-deploy example is in the README.</p>
    <div class="field"><label>Endpoint URL</label><input id="coachUrl" placeholder="https://your-app.vercel.app/api/coach" value="${esc(App.coachUrl)}"></div>
    <button class="btn primary" id="saveCoach">Save</button> <span id="coachSaved" class="hint"></span></div>
  <div class="card"><div class="eyebrow">Data</div>
    <p class="hint" style="margin:8px 0">Songs and recordings are stored on this device only.</p>
    <button class="btn" id="resetSongs">Reset song library to defaults</button></div>`;
}

/* ---------- add song ---------- */
function addSongPrompt(){
  $("#view").innerHTML=`<h2 class="sectiontitle">Add a song</h2><p class="sub">Chords as space-separated, like: Am G F E or A5 D5 G5.</p>
  <div class="card"><div class="field"><label>Title</label><input id="nTitle" placeholder="Song title"></div>
  <div class="field"><label>Band / artist</label><input id="nBand" placeholder="Artist"></div>
  <div class="grid2"><div class="field"><label>Key</label><input id="nKey" placeholder="e.g. Em"></div><div class="field"><label>Tempo (BPM)</label><input id="nTempo" type="number" value="100"></div></div>
  <div class="field"><label>Chords</label><input id="nChords" placeholder="Am G F E"></div>
  <div class="row" style="gap:10px"><button class="btn primary" id="saveSong" style="flex:1">Save song</button><button class="btn ghost" id="cancelSong">Cancel</button></div></div>`;
  $("#cancelSong").onclick=()=>{App.view="library";render();};
  $("#saveSong").onclick=()=>{const title=$("#nTitle").value.trim();if(!title){$("#nTitle").focus();return;}
    const s={id:"u"+Date.now(),title,band:$("#nBand").value.trim()||"Unknown",key:$("#nKey").value.trim(),tempo:parseInt($("#nTempo").value)||100,chords:parseChords($("#nChords").value)};
    App.songs.unshift(s);Store.set("songs",App.songs);App.view="library";render();};
}
function parseChords(str){return str.trim().split(/\s+/).filter(Boolean).map(tok=>{const m=tok.match(/^([A-Ga-g])([#b]?)(.*)$/);if(!m)return null;let root=m[1].toUpperCase();if(m[2]==="#")root+="#";else if(m[2]==="b"){const fl={C:"B",D:"C#",E:"D#",F:"E",G:"F#",A:"G#",B:"A#"};root=fl[root]||root;}let suf=m[3].toLowerCase(),type="major";if(suf==="m"||suf==="min")type="minor";else if(suf==="7")type="7";else if(suf==="m7")type="m7";else if(suf==="5")type="5";else if(suf==="sus4"||suf==="sus")type="sus4";else if(suf==="dim")type="dim";else if(suf==="maj7")type="maj7";return [root,type];}).filter(Boolean);}

/* ---------- helpers ---------- */
function chordSuffix(t){return {major:"",minor:"m","7":"7",m7:"m7","5":"5",sus4:"sus4",dim:"dim",maj7:"maj7"}[t]??"";}
function esc(s){return String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));}

/* play + visual flash for the SVG instruments */
function flash(el){ if(!el)return; el.classList.add("hit"); setTimeout(()=>el.classList.remove("hit"),140); }
function flashStr(host,i){ const s=host.querySelector(`.gstr[data-str="${i}"]`); if(s){s.classList.add("twang");setTimeout(()=>s.classList.remove("twang"),180);} }
function playOpen(host,i){ const s=GSTRINGS[i]; pluck(nf(s.open,s.oct)); flashStr(host,i); }
function bindInstrument(){
  const host=$("#instrument"); if(!host) return;
  host.style.touchAction="manipulation";
  host.addEventListener("pointerdown",e=>{
    const k=e.target.closest("[data-kit]"); if(k){drum(k.dataset.kit);flash(k);return;}
    const fr=e.target.closest("[data-fret]"); if(fr){const [i,f]=fr.dataset.fret.split(",").map(Number);const s=GSTRINGS[i];const n=fretNote(s.open,s.oct,f);pluck(nf(n.note,n.oct));flash(fr);flashStr(host,i);return;}
    const op=e.target.closest("[data-open]"); if(op){playOpen(host,+op.dataset.open);}
  });
  $("#strumBtn")?.addEventListener("click",()=>{ for(let i=5;i>=0;i--){const s=GSTRINGS[i];pluck(nf(s.open,s.oct),(5-i)*0.045);setTimeout(()=>flashStr(host,i),(5-i)*45);} });
}

/* ---------- nav + instrument ---------- */
const ICONS={
  library:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19V5a2 2 0 0 1 2-2h10l4 4v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2Z"/><path d="M8 8h6M8 12h8M8 16h5"/></svg>',
  record:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5" fill="currentColor"/></svg>',
  clips:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 9l5 3-5 3V9Z"/></svg>',
  settings:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.5-2.4 1a7 7 0 0 0-1.7-1L14.5 2h-5l-.3 2.5a7 7 0 0 0-1.7 1l-2.4-1-2 3.5L2.6 11a7 7 0 0 0 0 2l-2 1.5 2 3.5 2.4-1a7 7 0 0 0 1.7 1l.3 2.5h5l.3-2.5a7 7 0 0 0 1.7-1l2.4 1 2-3.5-2-1.5c.1-.3.1-.7.1-1Z"/></svg>'
};
function renderNav(){
  const tabs=[["library","Set list"],["record","Record"],["clips","Takes"],["settings","Settings"]];
  $("#nav").innerHTML=tabs.map(([k,l])=>`<button data-tab="${k}" aria-current="${App.view===k||(k==='library'&&App.view==='song')}">${ICONS[k]}<span>${l}</span></button>`).join("");
  $("#nav").querySelectorAll("button").forEach(b=>b.onclick=()=>{stopMetro();App.view=b.dataset.tab;render();});
}
function syncInstUI(){$("#instGuitar").setAttribute("aria-pressed",App.inst==="guitar");$("#instDrums").setAttribute("aria-pressed",App.inst==="drums");}
$("#instGuitar").onclick=()=>{App.inst="guitar";Store.set("inst","guitar");syncInstUI();render();};
$("#instDrums").onclick=()=>{App.inst="drums";Store.set("inst","drums");syncInstUI();render();};

/* ---------- per-view binding ---------- */
function bind(){
  $("#search")?.addEventListener("input",e=>{App.q=e.target.value;$("#view").innerHTML=Library();bind();const s=$("#search");s.focus();s.setSelectionRange(App.q.length,App.q.length);});
  $("#addSong")?.addEventListener("click",addSongPrompt);
  document.querySelectorAll("[data-song]").forEach(b=>b.onclick=()=>{App.selected=b.dataset.song;App.view="song";render();});

  $("#back")?.addEventListener("click",()=>{stopMetro();App.view="library";render();});
  document.querySelectorAll("[data-chord]").forEach(b=>b.onclick=()=>{const s=App.songs.find(x=>x.id===App.selected);const c=s.chords[+b.dataset.chord];chord(c[0],c[1]);});
  bindInstrument();
  document.querySelector("[data-del]")?.addEventListener("click",e=>{const id=e.target.dataset.del;App.songs=App.songs.filter(s=>s.id!==id);Store.set("songs",App.songs);stopMetro();App.view="library";render();});
  $("#playProg")?.addEventListener("click",()=>{const s=App.songs.find(x=>x.id===App.selected);const beat=60/(s.tempo||90);(s.chords||[]).forEach((c,i)=>setTimeout(()=>chord(c[0],c[1],beat*1.6),i*beat*1000*1.6));});
  const bpm=$("#bpm");
  if(bpm){const upd=v=>{$("#bpmLabel").textContent=v+" BPM";};bpm.addEventListener("input",e=>upd(e.target.value));
    $("#bpmUp").onclick=()=>{bpm.value=Math.min(220,+bpm.value+2);upd(bpm.value);};$("#bpmDown").onclick=()=>{bpm.value=Math.max(40,+bpm.value-2);upd(bpm.value);};
    $("#metroBtn").onclick=function(){if(metro){stopMetro();this.textContent="Start metronome";this.classList.remove("hot");}else{startMetro(+bpm.value);this.textContent="Stop metronome";this.classList.add("hot");}};}
  $("#goRecord")?.addEventListener("click",()=>{stopMetro();App.view="record";render();});

  if(App.view==="record"){setMode("audio");$("#mAudio").onclick=()=>setMode("audio");$("#mVideo").onclick=()=>setMode("video");
    $("#recBtn").onclick=()=>{if(recorder&&recorder.state==="recording")stopRec();else startRec();};
    $("#impBtn").onclick=()=>$("#impInput").click();
    $("#impInput").onchange=e=>{const f=e.target.files[0];if(!f)return;lastBlob=f;lastType=f.type.startsWith("video")?"video":"audio";$("#recStatus").textContent=`Imported ${f.name}. Analyzing…`;analyze(f,lastType==="video");};}

  if(App.view==="clips"){
    App.clips.forEach(c=>{const host=document.querySelector(`[data-clip="${c.id}"]`);if(!host)return;const url=URL.createObjectURL(c.blob);
      host.innerHTML=c.isVideo?`<video class="preview" controls playsinline src="${url}" style="margin-top:10px"></video>`:`<audio controls src="${url}"></audio>`;});
    document.querySelectorAll("[data-dlclip]").forEach(b=>b.onclick=()=>{const c=App.clips.find(x=>x.id===b.dataset.dlclip);const a=document.createElement("a");a.href=URL.createObjectURL(c.blob);a.download=`take.webm`;a.click();});
    document.querySelectorAll("[data-delclip]").forEach(b=>b.onclick=async()=>{await DB.del(b.dataset.delclip);App.clips=App.clips.filter(x=>x.id!==b.dataset.delclip);render();});
  }

  if(App.view==="settings"){
    $("#saveCoach").onclick=()=>{App.coachUrl=$("#coachUrl").value.trim();Store.set("coachUrl",App.coachUrl);$("#coachSaved").textContent="Saved.";};
    $("#resetSongs").onclick=()=>{App.songs=SEED.slice();Store.set("songs",App.songs);App.view="library";render();};
  }
}

boot();
